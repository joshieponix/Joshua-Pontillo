-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2024 at 08:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `applicant_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicant_info`
--

CREATE TABLE `applicant_info` (
  `id` bigint(11) NOT NULL,
  `schoolcode` int(10) DEFAULT NULL,
  `applicantcodeid` varchar(50) NOT NULL,
  `applicantno` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(70) NOT NULL,
  `midname` varchar(50) NOT NULL,
  `suffix` varchar(10) NOT NULL,
  `fullname` varchar(180) NOT NULL,
  `mobileno` varchar(15) NOT NULL,
  `emailadd` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applicant_info`
--

INSERT INTO `applicant_info` (`id`, `schoolcode`, `applicantcodeid`, `applicantno`, `lastname`, `firstname`, `midname`, `suffix`, `fullname`, `mobileno`, `emailadd`) VALUES
(1, 1023, '1093', '1902', 'Pontillo', 'Joshua', 'Yu', 'none', 'Joshua Yu Pontillo', '09482772125', 'pontillojoshua024@gmail.com'),
(2, 5180, '1925', '3008', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf', 'sdfg', 'sdfg'),
(3, 9727, '5324', '8378', 'Dela cruz', 'Juan', 'E.', 'Jr', 'Juan E. Dela cruz Jr', '09482466777', 'juan@gmail.com'),
(4, 8688, '7104', '2603', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf asdf asdf asdf', 'asdf', 'asdf'),
(5, 3796, '6782', '7927', 'sd', 'ddd', 'dd', 'dd', 'ddd dd sd dd', 'asdf', 'sdfg'),
(6, 6926, '7321', '3766', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf asdf asdf asdf', 'sdfg', 'sd'),
(7, 7595, '2175', '7230', 'zxcv', 'zxcv', 'zxcv', 'zxcv', 'zxcv zxcv zxcv zxcv', 'zxcv', 'asdf@gmail.com'),
(8, 9200, '1241', '1748', 'asdf', 'asdf', 'zxcv', 'zxcv', 'asdf zxcv asdf zxcv', 'asdf', 'asdf'),
(9, 3286, '7031', '2935', 'czx', 'vzxc', 'vzx', 'cv', 'vzxc vzx czx cv', 'zxcv', 'zxc'),
(10, 3964, '5584', '5363', 'sdf', 'asdf', 'asdf', 'asdf', 'asdf asdf sdf asdf', 'asdf', 'asdf@gmail.com'),
(11, 5228, '2845', '2928', 'Alarbe', 'Evangeline', 'D.', 'N/A', 'Evangeline D. Alarbe N/A', '09304437216', 'alarbe.evangeline03@gmail.com'),
(12, 6539, '4208', '4129', 'alarbe ', 'Evangeline', 'B.', 'N/A', 'Evangeline B. alarbe  N/A', '093567373883', 'alarbe.evengeline03@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicant_info`
--
ALTER TABLE `applicant_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicant_info`
--
ALTER TABLE `applicant_info`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
