document.getElementById("lastname").addEventListener("input", function () {
  if (document.getElementById("lastname").value.length > 0) {
    $("#lastname").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("firstname").addEventListener("input", function () {
  if (document.getElementById("firstname").value.length > 0) {
    $("#firstname").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("midname").addEventListener("input", function () {
  if (document.getElementById("midname").value.length > 0) {
    $("#midname").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("suffix").addEventListener("input", function () {
  if (document.getElementById("suffix").value.length > 0) {
    $("#suffix").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("nickname").addEventListener("input", function () {
  if (document.getElementById("nickname").value.length > 0) {
    $("#nickname").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("dob").addEventListener("input", function () {
  if (document.getElementById("dob").value.length > 0) {
    $("#dob").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("placeofbirth").addEventListener("input", function () {
  if (document.getElementById("placeofbirth").value.length > 0) {
    $("#placeofbirth").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("height").addEventListener("input", function () {
  if (document.getElementById("height").value.length > 0) {
    $("#height").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("weight").addEventListener("input", function () {
  if (document.getElementById("weight").value.length > 0) {
    $("#weight").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("gender").addEventListener("input", function () {
  if (document.getElementById("gender").value.length > 0) {
    $("#gender").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("language").addEventListener("input", function () {
  if (document.getElementById("language").value.length > 0) {
    $("#language").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("religion").addEventListener("input", function () {
  if (document.getElementById("religion").value.length > 0) {
    $("#religion").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("civilstatus").addEventListener("input", function () {
  if (document.getElementById("civilstatus").value.length > 0) {
    $("#civilstatus").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("spousename").addEventListener("input", function () {
  if (document.getElementById("spousename").value.length > 0) {
    $("#spousename").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("occupation").addEventListener("input", function () {
  if (document.getElementById("occupation").value.length > 0) {
    $("#occupation").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("children").addEventListener("input", function () {
  if (document.getElementById("children").value.length > 0) {
    $("#children").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("email").addEventListener("input", function () {
  if (document.getElementById("email").value.length > 0) {
    $("#email").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("mobile").addEventListener("input", function () {
  if (document.getElementById("mobile").value.length > 0) {
    $("#mobile").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("viber").addEventListener("input", function () {
  if (document.getElementById("viber").value.length > 0) {
    $("#viber").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("telephone").addEventListener("input", function () {
  if (document.getElementById("telephone").value.length > 0) {
    $("#telephone").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("street").addEventListener("input", function () {
  if (document.getElementById("street").value.length > 0) {
    $("#street").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("country").addEventListener("input", function () {
  if (document.getElementById("country").value.length > 0) {
    $("#country").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("region").addEventListener("input", function () {
  if (document.getElementById("region").value.length > 0) {
    $("#region").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("municipal").addEventListener("input", function () {
  if (document.getElementById("municipal").value.length > 0) {
    $("#municipal").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("zipcode").addEventListener("input", function () {
  if (document.getElementById("zipcode").value.length > 0) {
    $("#zipcode").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("barangay").addEventListener("input", function () {
  if (document.getElementById("barangay").value.length > 0) {
    $("#barangay").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("mailingAddress").addEventListener("input", function () {
  if (document.getElementById("mailingAddress").value.length > 0) {
    $("#mailingAddress").css({
      border: "1px solid silver",
    });
    return true;
  }
});

document.getElementById("contactNumber").addEventListener("input", function () {
  if (document.getElementById("contactNumber").value.length > 0) {
    $("#contactNumber").css({ 
      border: "1px solid silver",
    });
    return true;
  }
});