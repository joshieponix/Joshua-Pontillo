$(document).ready(function () {
  $("#refresh-button").click(function () {
    Swal.fire({
      title: "Reloading...",
      text: "Please wait while we reloading.",
      icon: "info",
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => {
        Swal.showLoading(); // Show loading spinner
        // Simulate a process (e.g., submitting data, fetching results, etc.)
        setTimeout(() => {
          window.location.reload();
        }, 3000); // 3 seconds delay
      },
    });
  });
});
