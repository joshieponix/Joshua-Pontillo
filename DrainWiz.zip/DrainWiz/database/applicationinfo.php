<?php
// Database connection
include "dbConnection.php";

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Set values
        $schoolcode = $_POST['schoolcode'];
        $applicantcodeid = $_POST['applicantcodeid'];
        $applicantno = $_POST['applicantno'];
        $lastname = $_POST['lastname'];
        $firstname = $_POST['firstname'];
        $midname = $_POST['midname'];
        $suffix = $_POST['suffix'];
        $fullname = $_POST['fullname']; // This is already concatenated in the form
        $mobileno = $_POST['mobileno'];
        $emailadd = $_POST['emailadd'];
        // SQL insert statement
        $sql = "INSERT INTO applicant_info (schoolcode, applicantcodeid, applicantno, lastname, firstname, midname, suffix, fullname, mobileno, emailadd) 
            VALUES (:schoolcode, :applicantcodeid, :applicantno, :lastname, :firstname, :midname, :suffix, :fullname, :mobileno, :emailadd)";

        // Prepare the statement
        $stmt = $pdo->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':schoolcode', $schoolcode);
        $stmt->bindParam(':applicantcodeid', $applicantcodeid);
        $stmt->bindParam(':applicantno', $applicantno);
        $stmt->bindParam(':lastname', $lastname);
        $stmt->bindParam(':firstname', $firstname);
        $stmt->bindParam(':midname', $midname);
        $stmt->bindParam(':suffix', $suffix);
        $stmt->bindParam(':fullname', $fullname);
        $stmt->bindParam(':mobileno', $mobileno);
        $stmt->bindParam(':emailadd', $emailadd);


        // Execute the statement
        $stmt->execute();

        echo "Record inserted successfully!";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close connection
$pdo = null;
