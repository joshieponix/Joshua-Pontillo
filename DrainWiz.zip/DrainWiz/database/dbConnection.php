<?php
$host = 'localhost'; // Replace with your database host
$db = 'applicant_info'; // Replace with your database name
$user = 'root'; // Replace with your database username
$pass = ''; // Replace with your database password
$charset = 'utf8mb4'; // The character set to use

$dsn = "mysql:host=$host;dbname=$db;charset=$charset"; // Data Source Name

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Enable exceptions for errors
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Set default fetch mode to associative array
    PDO::ATTR_EMULATE_PREPARES   => false, // Disable emulation of prepared statements
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options); // Create a new PDO instance
    echo "Connection successful!";
} catch (PDOException $e) {
    // Handle connection errors
    echo 'Connection failed: ' . $e->getMessage();
}
